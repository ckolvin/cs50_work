from cs50 import get_string


your_name = input("What is your name?\n")
print("hello, {}".format(your_name))
